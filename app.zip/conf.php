<?php
       
	//define('SHOPIFY_APP_API_KEY', 'a1d8a4ace6eaa1e0241afa2dcd19132c');
	//define('SHOPIFY_APP_SHARED_SECRET', 'fdf3bce4b18ab3c6bf490118795dda47');
	
	define('SHOPIFY_APP_API_KEY', 'ba6421ebae4dc7690dc14d55148c1bf2');
	define('SHOPIFY_APP_SHARED_SECRET', '9238a2aa31f22861abe7fd8c99ff6736');
	
?>

